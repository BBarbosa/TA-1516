------------------------ diabetic_foot.m -------------------------------

The diabetic_foot.m is a MATLAB(R) scritp and was tested on MATLAB 2015.

To run it, just open MATLAB and press F5.
------------------------------------------------------------------------ 